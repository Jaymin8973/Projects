import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';

function Add_categories() {
  const [formvalue, setFormvalue] = useState({
    id: "",
    name:"",
    img:""
  });

  const changehandel=(e)=>{

    setFormvalue({...formvalue,id:new Date().getTime().toString(),[e.target.name]:e.target.value});
    console.log(formvalue);
    
}



  const submithandel = async (e) => {
    e.preventDefault();
    const res = await axios.post(`http://localhost:3000/categories`, formvalue);
    console.log(res);
    if (res.status == 201) {
      toast.success('category Add success !');
      setFormvalue({ ...formvalue,name: "", img: "" });
    }
  }
  return (
    <div>
      <div className="container-fluid col-md-8">
        <div className="container-fluid">
          <div className="card">
            <div className="card-body">
              <h1 className="card-title fw-semibold mb-4">Add Categories</h1>
              <div className="card">
                <div className="card-body">
                  <form method='post'>
                    <div className="mb-3">
                      <label htmlFor="exampleInputEmail1" className="form-label">cate_name</label>
                      <input type="text" value={formvalue.name} onChange={changehandel} className="form-control" id="exampleInputEmail1" name="name" aria-describedby="emailHelp" />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="exampleInputPassword1" className="form-label">cate_img</label>
                      <input type="url" value={formvalue.img} onChange={changehandel} className="form-control" id="exampleInputPassword1" name="img" />
                    </div>
                    <button type="submit" className="btn btn-primary" onClick={submithandel}>Submit</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Add_categories