import React, { useState, useEffect } from 'react'
import {useNavigate, useParams} from 'react-router-dom'
import axios from 'axios';
import {toast} from 'react-toastify';

function Edit_product() {

    useEffect(() => {
        editdata();
    }, []);

    const [formvalue,setFormvalue]=useState({
        id:"",
        title:"",
        desc:"",
        img:"",
    })

    const {id}=useParams();
    const editdata = async () => {
        const res = await axios.get(`http://localhost:3000/product/${id}`);
        //console.log(res.data);
        setFormvalue({...formvalue,id:res.data.id,title:res.data.title,desc:res.data.desc,img:res.data.img});
    }


  

    const changehandel=(e)=>{
        setFormvalue({...formvalue,[e.target.name]:e.target.value});
        console.log(formvalue);
    }


    const validation=()=>{
        let result=true;
        if(formvalue.title=="" || formvalue.title==null)
        {
            toast.error('title field is required !');
            result=false;
        }
        
        if(formvalue.desc=="" || formvalue.desc==null)
        {
            toast.error('desc field is required !');
            result=false;
        }
        if(formvalue.img=="" || formvalue.img==null)
        {
            toast.error('img field is required !');
            result=false;
        }

        return result;
    }

    const redirect=useNavigate();
    const submithandel=async(e)=>{
        
        e.preventDefault();// not refresh page on submit
        if(validation())
        {
            const res=await axios.patch(`http://localhost:3000/product/${formvalue.id}`,formvalue);
            if(res.status==200)
            {
                toast.success('Update Success !');
                setFormvalue({...formvalue,title:"",desc:"",img:""});
                return redirect('/manage_product');     
            }   
        }
    }

    return (
        <div>
        <div className="container-fluid col-md-8">
     <div className="container-fluid">
       <div className="card"> 
         <div className="card-body">
           <h1 className="card-title fw-semibold mb-4">Add Product</h1>
           <div className="card">
             <div className="card-body">
               <form method='post'>
                 <div className="mb-3">
                   <label htmlFor="exampleInputEmail1" className="form-label">title</label>
                   <input value={formvalue.title} onChange={changehandel} type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='title' />
                 </div>
                 <div className="mb-3">
                   <label htmlFor="exampleInputEmail1" className="form-label">desc</label>
                   <input value={formvalue.desc}type="text"onChange={changehandel} className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='desc' />
                 </div>
                 <div className="mb-3">
                   <label htmlFor="exampleInputPassword1" className="form-label">img link</label>
                   <input value={formvalue.img}type="url" onChange={changehandel} className="form-control" id="exampleInputPassword1" name='img' />
                 </div>
                 <button type="submit" className="btn btn-primary" onClick={submithandel}>Submit</button>
               </form>
             </div>
           </div>
         </div>
       </div>
     </div>
   </div>
     </div>
    )
}

export default Edit_product