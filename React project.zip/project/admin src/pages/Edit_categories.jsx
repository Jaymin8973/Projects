import React, { useState, useEffect } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import axios from 'axios';
import { toast } from 'react-toastify';

function Edit_categories() {

    useEffect(() => {
        editdata();
    }, []);

    const [formvalue, setFormvalue] = useState({
        id: "",
        name: "",
        img: ""
    })

    const { id } = useParams();
    const editdata = async () => {
        const res = await axios.get(`http://localhost:3000/categories/${id}`);
        //console.log(res.data);
        setFormvalue({ ...formvalue, id: res.data.id, name: res.data.name,  img: res.data.img });
    }




    const changehandel = (e) => {
        setFormvalue({ ...formvalue, [e.target.name]: e.target.value });
        console.log(formvalue);
    }


    const validation = () => {
        let result = true;
        if (formvalue.name == "" || formvalue.name == null) {
            toast.error('desc field is required !');
            result = false;
        }
        if (formvalue.img == "" || formvalue.img == null) {
            toast.error('img field is required !');
            result = false;
        }

        return result;
    }

    const redirect = useNavigate();
    const submithandel = async (e) => {

        e.preventDefault();// not refresh page on submit
        if (validation()) {
            const res = await axios.patch(`http://localhost:3000/categories/${formvalue.id}`, formvalue);
            if (res.status == 200) {
                toast.success('Update Success !');
                setFormvalue({ ...formvalue, name: "", img: "" });
                return redirect('/manage_categories');
            }
        }
    }

    return (
        <div>
      <div className="container-fluid col-md-8">
        <div className="container-fluid">
          <div className="card">
            <div className="card-body">
              <h1 className="card-title fw-semibold mb-4">Add Categories</h1>
              <div className="card">
                <div className="card-body">
                  <form method='post'>
                    <div className="mb-3">
                      <label htmlFor="exampleInputEmail1" className="form-label">cate_name</label>
                      <input type="text" value={formvalue.name} onChange={changehandel} className="form-control" id="exampleInputEmail1" name="name" aria-describedby="emailHelp" />
                    </div>
                    <div className="mb-3">
                      <label htmlFor="exampleInputPassword1" className="form-label">cate_img</label>
                      <input type="url" value={formvalue.img} onChange={changehandel} className="form-control" id="exampleInputPassword1" name="img" />
                    </div>
                    <button type="submit" className="btn btn-primary" onClick={submithandel}>Submit</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    )
}

export default Edit_categories