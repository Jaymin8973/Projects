import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';




function Add_product() {
  const [formvalue,setFormvalue]=useState({
    id:"",
    title:"",
    desc:"",
    img:"",
    
  });
  
  const changehandel=(e)=>{

    setFormvalue({...formvalue,id:new Date().getTime().toString(),[e.target.name]:e.target.value});
    console.log(formvalue);
}
  
  const submithandel=async(e)=>{
    e.preventDefault();
    const res=await axios.post(`http://localhost:3000/product`,formvalue);
    console.log(res);
    if(res.status==201)
    {
        toast.success('Product Add success !');
        setFormvalue({...formvalue,title:"",desc:"",img:""});
    }
  }
  return (
    <div>
       <div className="container-fluid col-md-8">
    <div className="container-fluid">
      <div className="card"> 
        <div className="card-body">
          <h1 className="card-title fw-semibold mb-4">Add Product</h1>
          <div className="card">
            <div className="card-body">
              <form method='post'>
                <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">title</label>
                  <input value={formvalue.title} onChange={changehandel} type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='title' />
                </div>
                <div className="mb-3">
                  <label htmlFor="exampleInputEmail1" className="form-label">desc</label>
                  <input value={formvalue.desc}type="text"onChange={changehandel} className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name='desc' />
                </div>
                <div className="mb-3">
                  <label htmlFor="exampleInputPassword1" className="form-label">img link</label>
                  <input value={formvalue.img}type="url" onChange={changehandel} className="form-control" id="exampleInputPassword1" name='img' />
                </div>
                <button type="submit" className="btn btn-primary" onClick={submithandel}>Submit</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    </div>
  )
}

export default Add_product