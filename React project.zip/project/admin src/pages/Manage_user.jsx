import React, { useState, useEffect } from 'react'
import axios from 'axios';
import { toast } from 'react-toastify';
import {useNavigate} from'react-router-dom';

function Manage_user() {
  useEffect(() => {
    fetch();
  }, []);
  const redirect=useNavigate();
  const [data, Setdata] = useState([]);

  const fetch = async () => {
    const res = await axios.get('http://localhost:3000/user');
    //console.log(res.data);
    Setdata(res.data);
  }

  const deletedata = async (id) => {
    const res = await axios.delete(`http://localhost:3000/user/${id}`);
    toast.success('User delete success');
    fetch();
  }

  const status = async (id) => {
    const res = await axios.get(`http://localhost:3000/user/${id}`);
    // console.log(res.data);
    if (res.data.status == "Unblock") {
      const res = await axios.patch(`http://localhost:3000/user/${id}`, { status: "Block" });
      toast.success('User Block success');
      fetch();
    }
    else {
      const res = await axios.patch(`http://localhost:3000/user/${id}`, { status: "Unblock" });
      toast.success('User Unblock success');
      fetch();
    }

  }
  return (
    <div>
      <div className="container-fluid col-md-8 ">
        <table class="table table-dark ms-5 ">
          <thead>
            <tr>
              <th>id</th>
              <th>name</th>
              <th>email</th>
              <th>password</th>
              <th>mobile</th>
              <th>img</th>
              <th>status</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {
              data.map((value, index, entarr) => {
                return (
                  <tr>
                    <td>{value.id}</td>
                    <td>{value.name}</td>
                    <td>{value.email}</td>
                    <td>{value.password}</td>
                    <td>{value.mobile}</td>
                    <td><img src={value.img} width="100px" alt="" /></td>
                    <td><button onClick={() => { status(value.id); }} className='btn btn-danger'>{value.status}</button></td>
                    <td>
                      <button className='btn btn-info'onClick={ ()=>{ redirect('/edit_user/'+ value.id) }}>Edit</button>

                    </td>
                    <td>
                      <button onClick={() => { deletedata(value.id); }} className='btn btn-danger'>Delete</button>
                    </td>

                  </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Manage_user