import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
function Add_emp() {
    const [formvalue,setFormvalue]=useState({
        id:"",
        name:"",
        email:"",
        password:"",
        mobile:"",
        img:"",
        
      });
      
      const changehandel=(e)=>{
    
        setFormvalue({...formvalue,id:new Date().getTime().toString(),created_at:new Date(),updated_at:new Date(),[e.target.name]:e.target.value});
        console.log(formvalue);
    }
      
      const submithandel=async(e)=>{
        e.preventDefault();
        const res=await axios.post(`http://localhost:3000/employee`,formvalue);
        console.log(res);
        if(res.status==201)
        {
            toast.success('Employee Add success !');
            setFormvalue({...formvalue, id:"",name:"",email:"",password:"",mobile:"",img:""});
        }
      }
    return (
        <div>
            <div className="container-fluid col-md-8">
                <div className="container-fluid">
                    <div className="card">
                        <div className="card-body">
                            <h5 className="card-title fw-semibold mb-4">Add employee</h5>
                            <div className="card">
                                <div className="card-body">
                                    <form>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Name </label>
                                            <input value={formvalue.name} onChange={changehandel} type="text" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name"/>
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">Email </label>
                                            <input value={formvalue.email} onChange={changehandel} type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email"/>
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputPassword1" className="form-label">Password</label>
                                            <input value={formvalue.password} onChange={changehandel} type="password" className="form-control" id="exampleInputPassword1" name="password" />
                                        </div>
                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">mobile </label>
                                            <input value={formvalue.mobile} onChange={changehandel} type="number" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="mobile"/>
                                        </div>

                                        <div className="mb-3">
                                            <label htmlFor="exampleInputEmail1" className="form-label">img link</label>
                                            <input  value={formvalue.img} onChange={changehandel} type="url" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="img"/>
                                        </div>

                                        <button type="submit" onClick={submithandel} className="btn btn-primary">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Add_emp