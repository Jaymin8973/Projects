import React, { useState, useEffect } from 'react'
import axios from 'axios';
import {useNavigate} from'react-router-dom';
import { toast } from 'react-toastify';
function Manage_categories() {
  useEffect(() => {
    fetch();
  }, []);
  const redirect=useNavigate();
  const [data, Setdata] = useState([]);

  const fetch = async () => {
    const res = await axios.get('http://localhost:3000/categories');
    //console.log(res.data);
    Setdata(res.data);
  }

  const deletedata = async (id) => {
    const res = await axios.delete(`http://localhost:3000/categories/${id}`);
    toast.success('category delete success');
    fetch();
  }
  return (
    <div>
      <div className="container-fluid col-md-8 ">
        <table class="table table-striped ms-5">
          <thead>
            <tr>
              <th>id</th>
              <th>cate_name</th>
              <th>cate_img</th>
              <th>Edit</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
            {
              data.map((value, index, entarr) => {
                return (
                  <tr>
                    <td>{value.id}</td>
                    <td>{value.name}</td>
                    <td><img src={value.img} width="100px" alt="" /></td>
                    <td>  <button className='btn btn-info'onClick={ ()=>{ redirect('/edit_categories/'+ value.id) }}>Edit</button></td>
                    <td>  <button onClick={() => { deletedata(value.id); }} className='btn btn-danger'>Delete</button></td>
                  </tr>
                )
              })
            }
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Manage_categories