import { ToastContainer } from 'react-toastify';
  import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter,Routes,Route } from "react-router-dom";
import Header from "./component/Header";
import Add_product from "./pages/Add_product";
import Manage_product from "./pages/Manage_product";
import Add_emp from "./pages/Add_emp";
import Add_categories from "./pages/Add_categories";
import Manage_categories from "./pages/Manage_categories";
import Manage_emp from "./pages/Manage_emp";
import Add_user from "./pages/Add_user";
import Manage_user from "./pages/Manage_user";
import Login from './pages/Login';
import Index from './pages/Index';
import Edit_emp from './pages/Edit_emp';
import Edit_product from './pages/Edit_product';
import Edit_categories from './pages/Edit_categories';
import Edit_user from './pages/Edit_user';
  


function App() {
  return (
   
    <>
    <BrowserRouter>
    <ToastContainer/>
    <Routes>
    {(()=>{
          if(localStorage.getItem('adminid'))
          {
            return(
          <>
      <Route path="/" element={<><Login/></>}></Route>
      <Route path="/index" element={<><Header/><Index/></>}></Route>
      <Route path="/add_product"element={<><Header/><Add_product/></>}></Route>
      <Route path="/manage_product"element={<><Header/><Manage_product/></>}></Route>
      <Route path="/add_emp"element={<><Header/><Add_emp/></>}></Route>
      <Route path="/edit_emp/:id"  element={<><Edit_emp/></>}></Route>
      <Route path="/edit_product/:id"  element={<><Edit_product/></>}></Route>
      <Route path="/edit_user/:id"  element={<><Edit_user/></>}></Route>
      <Route path="/edit_categories/:id"  element={<><Edit_categories/></>}></Route>
      <Route path="/manage_emp"element={<><Header/><Manage_emp/></>}></Route>
      <Route path="/add_categories"element={<><Header/><Add_categories/></>}></Route>
      <Route path="/manage_categories"element={<><Header/><Manage_categories/></>}></Route>
      <Route path="/add_user"element={<><Header/><Add_user/></>}></Route>
      <Route path="/manage_user"element={<><Header/><Manage_user/></>}></Route>
      </>
       )
      }
      else
      {
        return(
          <>
          <Route path="/" element={<><Login/></>}></Route>
          </>
        )
      }
    })()}

        
  </Routes>
</BrowserRouter>
</>
)
  };
     

export default App;
