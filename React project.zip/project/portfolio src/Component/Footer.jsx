import React from 'react'

function Footer() {
  return (
<div>
  {/* Footer */}
  <section className="w3l-footer py-sm-5 py-4">
    <div className="container">
      <div className="footer-content">
        <div className="row">
          <div className="col-lg-8 footer-left">
            <p className="m-0">Alexander © Copyright 2020. Design by <a href="https://w3layouts.com">W3layouts</a></p>
          </div>
          <div className="col-lg-4 footer-right text-lg-right text-center mt-lg-0 mt-3">
            <ul className="social m-0 p-0">
              <li><a href="#facebook"><span className="fa fa-facebook-official" /></a></li>
              <li><a href="#linkedin"><span className="fa fa-linkedin-square" /></a></li>
              <li><a href="#instagram"><span className="fa fa-instagram" /></a></li>
              <li><a href="#twitter"><span className="fa fa-twitter" /></a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    {/* move top */}
    <button onclick="topFunction()" id="movetop" title="Go to top">
      <span className="fa fa-angle-up" />
    </button>
  </section>
  {/* //Footer */}
</div>



  )
}

export default Footer