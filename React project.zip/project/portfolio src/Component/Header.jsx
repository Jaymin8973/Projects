import React from 'react'
import { NavLink, Link, useNavigate } from 'react-router-dom'
import { toast } from 'react-toastify';

function Header() {

  const redirect = useNavigate();
  const logout = () => {
    localStorage.removeItem('user_id');
    localStorage.removeItem('user_name');
    toast.success('Logout Success');
    return redirect('/');
  }
  return (
    <div>
      {/* header */}
      <header id="site-header" className="fixed-top">
        <div className="container">
          <nav className="navbar navbar-expand-lg stroke">
            <a className="navbar-brand" to="index.html">
              <span className="fa fa-laptop" /> Alexander
            </a>
            {/* if logo is image enable this   
<a class="navbar-brand" to="#index.html">
    <img src="image-path" alt="Your logo" title="Your logo" style="height:35px;" />
</a> */}
            <button className="navbar-toggler  collapsed bg-gradient" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon fa icon-expand fa-bars" />
              <span className="navbar-toggler-icon fa icon-close fa-times" />
            </button>
            <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
              <ul className="navbar-nav ml-auto">
                <li className="nav-item ">
                  <NavLink className="nav-link" to="/">Home <span className="sr-only">(current)</span></NavLink>
                </li>
                <li className="nav-item ">
                  <NavLink className="nav-link" to="/about">About</NavLink>
                </li>
                <li className="nav-item ">
                  <NavLink className="nav-link" to="/contact">Contact</NavLink>
                </li>
                <li className="nav-item ">
                  <NavLink className="nav-link" to="/service">service</NavLink>
                </li>
                {(() => {
                  if (localStorage.getItem('user_id')) {
                    return (
                      <>
                        <li className="nav-item">
                          <NavLink className="nav-link" to="/profile">MyAccount</NavLink>
                        </li>

                        <li className="nav-item">
                          <a className="nav-link" onClick={logout} href="javascript:void(0)">Logout</a>
                        </li>
                      </>
                    )
                  }
                  else {
                    return (
                      <li className="nav-item">
                        <NavLink className="nav-link" to="/signup">Signup</NavLink>
                      </li>
                    )
                  }
                })()}
              </ul>
            </div>
            {/* toggle switch for light and dark theme */}
            <div className="mobile-position">
              <nav className="navigation">
                <div className="theme-switch-wrapper">
                  <label className="theme-switch" htmlFor="checkbox">
                    <input type="checkbox" id="checkbox" />
                    <div className="mode-container">
                      <i className="gg-sun" />
                      <i className="gg-moon" />
                    </div>
                  </label>
                </div>
              </nav>
            </div>
            {/* //toggle switch for light and dark theme */}
          </nav>
        </div>
      </header>
      {/* //header */}
    </div>

  )
}

export default Header