import React,{useState} from 'react'
import { Link ,useNavigate} from 'react-router-dom'
import axios from 'axios';

import {toast} from 'react-toastify'
function Login() {

    const redirect=useNavigate();

    const [formvalue,setFormvalue]=useState({
        email:"",
        password:"",
    })

    const changehandel=(e)=>{
        setFormvalue({...formvalue,[e.target.name]:e.target.value});
        console.log(formvalue);
    }

    const validation=()=>{
        let result=true;
       
        if(formvalue.email=="" || formvalue.email==null)
        {
            toast.error('email field is required !');
            result=false;
        }
        if(formvalue.password=="" || formvalue.password==null)
        {
            toast.error('password field is required !');
            result=false;
        }
        return result;
    }

    const submithandel=async(e)=>{
        e.preventDefault();// not refresh page on submit
        if(validation())
        {
            const res=await axios.get(`http://localhost:3000/user?email=${formvalue.email}`);
            if(res.data.length>0)
            {
                if(res.data[0].password==formvalue.password)
                {
                    if(res.data[0].status=="Unblock")
                    {
                        //session created
                        localStorage.setItem('user_id',res.data[0].id);
                        localStorage.setItem('user_name',res.data[0].name);

                        toast.success('Login Success !');
                        setFormvalue({...formvalue,email:"",password:""}); 
                        return redirect('/');
                    }
                    else
                    {
                        toast.error('Your Account Blocked so Contact cusrtomer care!');
                        setFormvalue({...formvalue,email:"",password:""});
                    }
                }
                else
                {
                    toast.error('Wrong Password !');
                    setFormvalue({...formvalue,email:"",password:""});
                }
            }
            else
            {
                toast.error('Username not Found !');
                setFormvalue({...formvalue,email:"",password:""});
            }
        }
    }

    return (
        <div>
            {/* breadcrumb */}
            <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                        <a href="index">Home</a>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">Login</li>
                </ol>
            </nav>
            {/* breadcrumb */}
            {/* //banner */}
            {/* history */}
            <div className="about-page py-5">
                <div className="container py-xl-5 py-lg-3">
                    <h3 className="title text-capitalize font-weight-light text-dark text-center mb-5 font-weight-bold">Login
                        
                    </h3>
                    <div className="row about-head-wthree">
                        <div className="col-lg-12 ">
                            <div className="container mt-3">
                               
                                <form action="" method='post'>
                                    <div className="mb-3 mt-3">
                                        <label htmlFor="email">Email:</label>
                                        <input type="email" value={formvalue.email} onChange={changehandel} className="form-control" id="email" placeholder="Enter email" name="email" />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="pwd">Password:</label>
                                        <input type="password" value={formvalue.password} onChange={changehandel} className="form-control" id="pwd" placeholder="Enter password" name="password" />
                                    </div>
                                   
                                    <button type="submit" onClick={submithandel} className="btn btn-primary">Submit</button>
                                    <Link to="/signup" className='float-right'>If you Not Registered Then Signup Here</Link>
                                </form>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            {/* brands */}
            <div className="brands-w3ls py-md-5 py-4">
                <div className="container py-xl-3">
                    <ul className="list-unstyled">
                        <li>
                            <i className="fab fa-supple" />
                        </li>
                        <li>
                            <i className="fab fa-angrycreative" />
                        </li>
                        <li>
                            <i className="fab fa-aviato" />
                        </li>
                        <li>
                            <i className="fab fa-aws" />
                        </li>
                        <li>
                            <i className="fab fa-cpanel" />
                        </li>
                        <li>
                            <i className="fab fa-hooli" />
                        </li>
                        <li>
                            <i className="fab fa-node" />
                        </li>
                    </ul>
                </div>
            </div>
            {/* //brands */}
        </div>

    )
}

export default Login