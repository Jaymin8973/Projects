import React from 'react'

function Contact() {
  return (
  <div>
  {/* contact breadcrumb */}
  <section className="w3l-about-breadcrumb text-center">
    <div className="breadcrumb-bg breadcrumb-bg-about py-sm-5 py-4">
      <div className="container py-2">
        <h2 className="title">Contact Me</h2>
        <ul className="breadcrumbs-custom-path mt-2">
          <li><a href="#url">Home</a></li>
          <li className="active"><span className="fa fa-arrow-right mx-2" aria-hidden="true" /> Contact </li>
        </ul>
      </div>
    </div>
  </section>
  {/* contact breadcrumb */}
  {/* contact block */}
  {/* contact1 */}
  <section className="w3l-contact-1 py-5">
    <div className="contacts-9 py-lg-5 py-md-4">
      <div className="container">
        <div className="d-grid contact-view">
          <div className="cont-details">
            <div className="cont-top">
              <div className="cont-left text-center">
                <span className="fa fa-phone text-primary" />
              </div>
              <div className="cont-right">
                <h6>Call Me</h6>
                <p><a href="tel:+44 99 555 42">+123 45 67 89</a></p>
              </div>
            </div>
            <div className="cont-top margin-up">
              <div className="cont-left text-center">
                <span className="fa fa-envelope-o text-primary" />
              </div>
              <div className="cont-right">
                <h6>Email Me</h6>
                <p><a href="mailto:example@mail.com" className="mail">example@mail.com</a></p>
              </div>
            </div>
            <div className="cont-top margin-up">
              <div className="cont-left text-center">
                <span className="fa fa-map-marker text-primary" />
              </div>
              <div className="cont-right">
                <h6>Location</h6>
                <p>Address here, 208 Trainer Avenue street, Illinois, UK - 62617.</p>
              </div>
            </div>
          </div>
          <div className="map-content-9">
            <form action="https://sendmail.w3layouts.com/submitForm" method="post">
              <div className="twice-two">
                <input type="text" className="form-control" name="w3lName" id="w3lName" placeholder="Name" required />
                <input type="email" className="form-control" name="w3lSender" id="w3lSender" placeholder="Email" required />
              </div>
              <div className="twice">
                <input type="text" className="form-control" name="w3lSubject" id="w3lSubject" placeholder="Subject" required />
              </div>
              <textarea name="w3lMessage" className="form-control" id="w3lMessage" placeholder="Message" required defaultValue={""} />
              <div className="text-right">
                <button type="submit" className="btn btn-primary btn-style mt-4">Send Message</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* /contact1 */}
  <div className="map-iframe">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d317718.69319292053!2d-0.3817765050863085!3d51.528307984912544!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47d8a00baf21de75%3A0x52963a5addd52a99!2sLondon%2C+UK!5e0!3m2!1sen!2spl!4v1562654563739!5m2!1sen!2spl" width="100%" height={400} frameBorder={0} style={{border: 0}} allowFullScreen />
  </div>
  {/* //contact block */}
</div>

  )
}

export default Contact