import React,{useState} from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios';

import {toast} from 'react-toastify'

function Signup() {

    const [formvalue,setFormvalue]=useState({
        id:"",
        name:"",
        email:"",
        password:"",
        mobile:"",
        status:"",
        img:""
    })

    const changehandel=(e)=>{

        setFormvalue({...formvalue,id:new Date().getTime().toString(),status:"Unblock",[e.target.name]:e.target.value});
        console.log(formvalue);
    }


    const validation=()=>{
        let result=true;
        if(formvalue.name=="" || formvalue.name==null)
        {
            toast.error('Name field is required !');
            result=false;
        }
        
        if(formvalue.email=="" || formvalue.email==null)
        {
            toast.error('email field is required !');
            result=false;
        }
        else if(!formvalue.email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/))
        {
            toast.error('Enter valid email field !');
            result=false;
        }

        if(formvalue.password=="" || formvalue.password==null)
        {
            toast.error('password field is required !');
            result=false;
        }
        if(formvalue.mobile=="" || formvalue.mobile==null)
        {
            toast.error('mobile field is required !');
            result=false;
        }
        if(formvalue.img=="" || formvalue.img==null)
        {
            toast.error('img field is required !');
            result=false;
        }

        return result;
    }

    const submithandel=async(e)=>{
        
        e.preventDefault();// not refresh page on submit
        if(validation())
        {
            const res=await axios.post(`http://localhost:3000/user`,formvalue);
            if(res.status==201)
            {
                toast.success('Register Success !');
                setFormvalue({...formvalue,name:"",email:"",password:"",mobile:"",img:""});     
            }   
        }
    }
    return (
        <div>
             <div className="container-fluid col-md-8"></div>
            {/* breadcrumb */}
            <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                    <li className="breadcrumb-item">
                        <a href="index">Home</a>
                    </li>
                    <li className="breadcrumb-item active" aria-current="page">Signup</li>
                </ol>
            </nav>
            {/* breadcrumb */}
            {/* //banner */}
            {/* history */}
            <div className="about-page py-5">
                <div className="container py-xl-5 py-lg-3">
                    <h3 className="title text-capitalize font-weight-light text-dark text-center mb-5">Signup
                        <span className="font-weight-bold"></span>
                    </h3>
                    <div className="row about-head-wthree">
                        <div className="col-lg-12 ">
                            <div className="container mt-3">
                               
                                <form action="">
                                    <div className="mb-3 mt-3">
                                        <label htmlFor="Name">Name:</label>
                                        <input type="text" value={formvalue.name} onChange={changehandel} className="form-control" id="Name" placeholder="Enter Name" name="name" />
                                    </div>   
                                    <div className="mb-3 mt-3">
                                        <label htmlFor="email">Email:</label>
                                        <input type="email" value={formvalue.email} onChange={changehandel} className="form-control" id="email" placeholder="Enter email" name="email" />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="pwd">Password:</label>
                                        <input type="password" value={formvalue.password} onChange={changehandel} className="form-control" id="pwd" placeholder="Enter password" name="password" />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="mobile">Mobile:</label>
                                        <input type="number" value={formvalue.mobile} onChange={changehandel} className="form-control" id="pwd" placeholder="Enter Mobile" name="mobile" />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="mobile">Upload Img:</label>
                                        <input type="url" value={formvalue.img} onChange={changehandel} className="form-control" id="pwd" placeholder="Enter Image URL" name="img" />
                                    </div>
                                    <button type="submit" onClick={submithandel} className="btn btn-primary">Submit</button>
                                    <Link to="/login" className='float-right'>If you already Registered TheN Login Here</Link>
                                </form>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

            
        </div>

    )
}

export default Signup