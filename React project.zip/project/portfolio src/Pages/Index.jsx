import React from 'react'

function Index() {
  return (
    <div>
      {/* banner section */}
      <section id="home" className="w3l-banner py-5">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-lg-6 col-sm-12 mt-lg-0 mt-4">
              <span className="title-small">Hello</span>
              <h1 className="mb-2 title"> <span>I'm</span> Jaymin </h1>
              <h1 className="mb-4 title"> a  <span id="element">Mern Stack developer</span></h1>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Provident, excepturi.
                Distinctio accusantium fugit odit? Fugit ipsam. Sed ac fringilla ex. Nam mauris velit, ac
                cursus quis, non leo.</p>
              <div className="mt-sm-5 mt-4">
                <a className="btn btn-primary btn-style mr-2" href="contact.html"> Hire Me </a>
                <a className="btn btn-outline-primary btn-style mr-2" href="#portfolio"> Portfolio </a>
              </div>
            </div>
            <div className="col-lg-6 col-md-8 col-sm-10 mt-lg-0 mt-4">
              <div className="img-effect text-lg-center">
                <img src="assets/images/photo.png" alt="myphoto" className="img-fluid" />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* //banner section */}
      {/* home page about section */}
      <section className="w3l-index3" id="about">
        <div className="midd-w3 py-5">
          <div className="container py-lg-5 py-md-3">
            <div className="row">
              <div className="col-lg-4">
                <div className="position-relative">
                  <img src="assets/images/myphoto.jpg" alt className="radius-image img-fluid" />
                </div>
              </div>
              <div className="col-lg-8 mt-lg-0 mt-5">
                <h5 className="title-small mb-2">Who am i?</h5>
                <h3 className="title-big">I'm Alexander Smith, a visual UI/UX Designer and Web Developer</h3>
                <p className="mt-4">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
                  ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet consectetur adipisicing
                  elit. Non quae, fugiat consequatur voluptatem nihil ad. Lorem ipsum dolor sit amet. Lorem ipsum
                  dolor sit, amet consectetur adipisicing elit. Dolor ipsum non velit reprehenderit, molestias
                  culpa!</p>
                <a href="#download" className="btn btn-style btn-primary mt-lg-5 mt-4">Download CV</a>
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* //home page about section */}
      {/* home page second section */}
      <div className="py-5 w3l-resume">
        <div className="container py-lg-5 py-3">
          <h5 className="title-small mb-2"> My resume</h5>
          <h3 className="title-big mb-4">I Would Love to make your Ideas real </h3>
          <p>I love graphic design and photography and have been working on my portfolio since 2016. You can download my
            resume in order to learn the details of my professional life as a designer and photographer. Contact me and
            we will discuss your projects!</p>
          <div className="mt-5">
            <a href="#download" className="btn btn-style btn-primary">Download resume</a>
          </div>
        </div>
      </div>
      {/* //home page second section */}
      {/* home page services section */}
      <section className="w3l-services">
        <div className="blog py-5" id="services">
          <div className="container py-lg-5">
            <h5 className="title-small text-center">Services</h5>
            <h3 className="title-big text-center mb-sm-5 mb-4">What I do for you</h3>
            <div className="row">
              <div className="col-md-12 mx-auto pr-2">
                <div className="owl-two owl-carousel owl-theme">
                  <div className="item">
                    <div className="card">
                      <div className="box-wrap">
                        <div className="icon">
                          <span className="fa fa-pencil-square-o" />
                        </div>
                        <h4 className="number">01</h4>
                        <h4><a href="#url">UI/UX Design</a></h4>
                        <p>Lorem ipsum dolor sit amet sed consectetur adipisicing elit.
                          doloret quas saepe autem, dolor set.</p>
                        <a href="#read" className="read">Read more</a>
                      </div>
                    </div>
                  </div>
                  <div className="item">
                    <div className="card">
                      <div className="box-wrap">
                        <div className="icon">
                          <span className="fa fa-laptop" />
                        </div>
                        <h4 className="number">02</h4>
                        <h4><a href="#url">Web Development</a></h4>
                        <p>Lorem ipsum dolor sit amet sed consectetur adipisicing elit.
                          doloret quas saepe autem, dolor set.</p>
                        <a href="#read" className="read">Read more</a>
                      </div>
                    </div>
                  </div>
                  <div className="item">
                    <div className="card">
                      <div className="box-wrap">
                        <div className="icon">
                          <span className="fa fa-area-chart" />
                        </div>
                        <h4 className="number">03</h4>
                        <h4><a href="#url">Research &amp; Analysis</a></h4>
                        <p>Lorem ipsum dolor sit amet sed consectetur adipisicing elit.
                          doloret quas saepe autem, dolor set.</p>
                        <a href="#read" className="read">Read more</a>
                      </div>
                    </div>
                  </div>
                  <div className="item">
                    <div className="card">
                      <div className="box-wrap">
                        <div className="icon">
                          <span className="fa fa-pencil-square-o" />
                        </div>
                        <h4 className="number">04</h4>
                        <h4><a href="#url">UI/UX Design</a></h4>
                        <p>Lorem ipsum dolor sit amet sed consectetur adipisicing elit.
                          doloret quas saepe autem, dolor set.</p>
                        <a href="#read" className="read">Read more</a>
                      </div>
                    </div>
                  </div>
                  <div className="item">
                    <div className="card">
                      <div className="box-wrap">
                        <div className="icon">
                          <span className="fa fa-laptop" />
                        </div>
                        <h4 className="number">05</h4>
                        <h4><a href="#url">Web Development</a></h4>
                        <p>Lorem ipsum dolor sit amet sed consectetur adipisicing elit.
                          doloret quas saepe autem, dolor set.</p>
                        <a href="#read" className="read">Read more</a>
                      </div>
                    </div>
                  </div>
                  <div className="item">
                    <div className="card">
                      <div className="box-wrap">
                        <div className="icon">
                          <span className="fa fa-area-chart" />
                        </div>
                        <h4 className="number">06</h4>
                        <h4><a href="#url">Research &amp; Analysis</a></h4>
                        <p>Lorem ipsum dolor sit amet sed consectetur adipisicing elit.
                          doloret quas saepe autem, dolor set.</p>
                        <a href="#read" className="read">Read more</a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="mt-5 text-more">
              <p className="mt-4 pt-3 sample text-center">
                <a href="services.html">View All Services <span className="pl-2 fa fa-long-arrow-right" /></a>
              </p>
            </div>
          </div>
        </div>
      </section>
      {/* //home page services section */}
      {/* stats */}
      <section className="w3l-stats py-lg-5 py-4" id="stats">
        <div className="gallery-inner container py-md-5 py-4">
          <div className="row stats-con">
            <div className="col-sm-3 col-6 stats_info counter_grid">
              <span className="fa fa-laptop" />
              <p className="counter">700</p>
              <h4>Completed projects</h4>
            </div>
            <div className="col-sm-3 col-6 stats_info counter_grid1">
              <span className="fa fa-hourglass-end" />
              <p className="counter">120</p>
              <h4>In processes</h4>
            </div>
            <div className="col-sm-3 col-6 stats_info counter_grid mt-sm-0 mt-5">
              <span className="fa fa-gift" />
              <p className="counter">12</p>
              <h4>Awards Received</h4>
            </div>
            <div className="col-sm-3 col-6 stats_info counter_grid2 mt-sm-0 mt-5">
              <span className="fa fa-smile-o" />
              <p className="counter">1050</p>
              <h4>Happy Clients</h4>
            </div>
          </div>
        </div>
      </section>
      {/* //stats */}
      {/* testimonials */}
      <section className="w3l-clients" id="clients">
        {/* /grids */}
        <div className="cusrtomer-layout py-5">
          <div className="container py-lg-5 py-md-4">
            <div className="heading text-center mx-auto">
              <h6 className="title-small text-center">Testimonials</h6>
              <h3 className="title-big mb-md-5 mb-4">What my clients think about Me </h3>
            </div>
            {/* /grids */}
            <div className="testimonial-width">
              <div id="owl-demo1" className="owl-carousel owl-theme mb-4">
                <div className="item">
                  <div className="testimonial-content">
                    <div className="testimonial">
                      <blockquote>
                        <q>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae laudantium
                          voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                          Dolores molestias adipisci dolor sit amet!.</q>
                      </blockquote>
                      <div className="testi-des">
                        <div className="test-img"><img src="assets/images/team1.jpg" className="img-fluid" alt="client-img" />
                        </div>
                        <div className="peopl align-self">
                          <h3>John wilson</h3>
                          <p className="indentity">Seattle, Washington</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-content">
                    <div className="testimonial">
                      <blockquote>
                        <q>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae laudantium
                          voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                          Dolores molestias adipisci dolor sit amet!.</q>
                      </blockquote>
                      <div className="testi-des">
                        <div className="test-img"><img src="assets/images/team2.jpg" className="img-fluid" alt="client-img" />
                        </div>
                        <div className="peopl align-self">
                          <h3>Julia sakura</h3>
                          <p className="indentity">Seattle, Washington</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-content">
                    <div className="testimonial">
                      <blockquote>
                        <q>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae laudantium
                          voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                          Dolores molestias adipisci dolor sit amet!.</q>
                      </blockquote>
                      <div className="testi-des">
                        <div className="test-img"><img src="assets/images/team3.jpg" className="img-fluid" alt="client-img" />
                        </div>
                        <div className="peopl align-self">
                          <h3>Roy Linderson</h3>
                          <p className="indentity">Seattle, Washington</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-content">
                    <div className="testimonial">
                      <blockquote>
                        <q>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae laudantium
                          voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                          Dolores molestias adipisci dolor sit amet!.</q>
                      </blockquote>
                      <div className="testi-des">
                        <div className="test-img"><img src="assets/images/team4.jpg" className="img-fluid" alt="client-img" />
                        </div>
                        <div className="peopl align-self">
                          <h3>Mike Thyson</h3>
                          <p className="indentity">Seattle, Washington</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-content">
                    <div className="testimonial">
                      <blockquote>
                        <q>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae laudantium
                          voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                          Dolores molestias adipisci dolor sit amet!.</q>
                      </blockquote>
                      <div className="testi-des">
                        <div className="test-img"><img src="assets/images/team2.jpg" className="img-fluid" alt="client-img" />
                        </div>
                        <div className="peopl align-self">
                          <h3>Laura gill</h3>
                          <p className="indentity">Seattle, Washington</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="item">
                  <div className="testimonial-content">
                    <div className="testimonial">
                      <blockquote>
                        <q>Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae laudantium
                          voluptate rem ullam dolore nisi voluptatibus esse quasi, doloribus tempora.
                          Dolores molestias adipisci dolor sit amet!.</q>
                      </blockquote>
                      <div className="testi-des">
                        <div className="test-img"><img src="assets/images/team3.jpg" className="img-fluid" alt="client-img" />
                        </div>
                        <div className="peopl align-self">
                          <h3>Smith Johnson</h3>
                          <p className="indentity">Seattle, Washington</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* /grids */}
        </div>
        {/* //grids */}
      </section>
      {/* //testimonials */}
      {/* home page video popup section */}
      <section className="w3l-index5" id="about">
        <div className="new-block py-5">
          <div className="container py-lg-5">
            <div className="middle-section text-center">
              <div className="section-width">
                <h3 className="title-big">I can give your business a new creative start right away! Hire me for your
                  Awesome project</h3>
                <p className="mt-3">Lorem ipsum, dolor sit amet consectetur adipisicing elit. At, corrupti odit? At iure
                  facere,
                  porro repellat officia quas, dolores magnam assumenda soluta odit
                  harum
                  voluptate inventore ipsa maiores fugiat accusamus eos nulla. Iure voluptatibus explicabo
                  officia.</p>
              </div>
              <div className="history-info mt-5">
                <div className="position-relative">
                  <img src="assets/images/bg.jpg" className="img-fluid radius-image video-popup-image" alt="video-popup" />
                  <a href="#small-dialog" className="popup-with-zoom-anim play-view text-center position-absolute">
                    <span className="video-play-icon">
                      <span className="fa fa-play" />
                    </span>
                  </a>
                  {/* dialog itself, mfp-hide class is required to make dialog hidden */}
                  <div id="small-dialog" className="zoom-anim-dialog mfp-hide">
                    <iframe src="https://www.youtube.com/embed/Cu2VnoRcxKM" allowFullScreen />
                  </div>
                </div>
              </div>
              {/* dialog itself, mfp-hide class is required to make dialog hidden */}
              <div id="small-dialog" className="zoom-anim-dialog mfp-hide">
                <iframe src="https://www.youtube.com/embed/Z_KspIX1oXU" allowFullScreen />
              </div>
            </div>
          </div>
        </div>
      </section>
      {/* //home page video popup section */}
      {/* freelance hire me */}
      <section className="w3l-grid-quote text-center py-5">
        <div className="container py-3">
          <h6 className="title-small">Get in touch</h6>
          <h3 className="title-big mb-md-5 mb-4">Let's start a Project! Hire Me.</h3>
          <a href="contact.html" className="btn btn-style btn-primary mr-2">Hire Me </a>
          <a href="contact.html" className="btn btn-style btn-outline-primary">Get in touch</a>
        </div>
      </section>
      {/* //freelance hire me */}
    </div>

  )
}

export default Index