import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

function Services() {


  const redirect = useNavigate();
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch();
  }, []);

  const fetch = async () => {
    const res = await axios.get(`http://localhost:3000/product`);
    //console.log(res.data);
    setData(res.data);
  }
  return (
    <section className="bsb-service-7 py-5 py-xl-8 mt-5">
      <div className="container">
        <div className="row justify-content-md-center">
          <div className="col-12 col-md-10 col-lg-8 col-xl-7">
            <h3 className="fs-5 mb-2 text-secondary text-center text-uppercase">Services</h3>
            <h2 className="display-5 mb-5 mb-xl-9 text-center">We offer premier services where excellence meets affordability.</h2>
          </div>
        </div>
      </div>
      {
        data.map((value) => {

          return (

            <div className="container">
              <div className="row">
                <div className="col-12">
                  <div className="container-fluid bg-light border shadow">
                    <div className="row">
                      <div className="col-12 col-md-4 p-0">
                        <div className="card border-0 bg-transparent">
                          <div className="card-body text-center ">
                            
                              <img src={value.img} height="100px" alt />
                            
                            <h4 className="fw-bold text-uppercase mb-4">{value.title}</h4>
                            <p className="mb-4 text-secondary">{value.desc}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )
        })
      }

    </section>

  )
}

export default Services