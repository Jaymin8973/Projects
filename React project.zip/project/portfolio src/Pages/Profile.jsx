import axios from 'axios';
import React from 'react'

import { useState, useEffect } from 'react'
import { toast } from 'react-toastify';


function Profile() {

    // profile =====================================================================================
    useEffect(() => {
        fetch();
    }, []);

    const [data, Setdata] = useState({});

    const fetch = async () => {
        const res = await axios.get(`http://localhost:3000/user/${localStorage.getItem('user_id')}`);
        //console.log(res.data);
        Setdata(res.data);
    }


    
    // Edit =================================================================================
    const [formvalue,setFormvalue]=useState({
        id:"",
        name:"",
        email:"",
        mobile:"",
        img:""
    })

    const editdata = async (id) => {
        const res = await axios.get(`http://localhost:3000/user/${id}`);
        console.log(res.data);
        setFormvalue({...formvalue,id:res.data.id,name:res.data.name,email:res.data.email,mobile:res.data.mobile,img:res.data.img});
    }


    //update ==============================================================================
    
    const changehandel=(e)=>{
        setFormvalue({...formvalue,[e.target.name]:e.target.value});
        //console.log(formvalue);
    }


    const validation=()=>{
        let result=true;
        if(formvalue.name=="" || formvalue.name==null)
        {
            toast.error('Name field is required !');
            result=false;
        }
        
        if(formvalue.email=="" || formvalue.email==null)
        {
            toast.error('email field is required !');
            result=false;
        }
        else if(!formvalue.email.match(/^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/))
        {
            toast.error('Enter valid email field !');
            result=false;
        }

        if(formvalue.mobile=="" || formvalue.mobile==null)
        {
            toast.error('mobile field is required !');
            result=false;
        }
        if(formvalue.img=="" || formvalue.img==null)
        {
            toast.error('img field is required !');
            result=false;
        }

        return result;
    }

    const submithandel=async(e)=>{
        e.preventDefault();// not refresh page on submit
        if(validation())
        {
            const res=await axios.patch(`http://localhost:3000/user/${formvalue.id}`,formvalue);
            //console.log(res);
            if(res.status==200)
            {
                toast.success('Update Success !');
                setFormvalue({...formvalue,name:"",email:"",mobile:"",img:""});
                fetch();     
            }   
        }
    }



    return (
        <section className="about_section layout_padding">
            <div className="container">
                <h1 align="center" className='m-5'>My Profile</h1>
                <div className="row">
                    <div className="col-lg-8 col-md-8">
                        <div className="detail-box">
                            <h1>
                                Name :  {data.name}
                            </h1>
                            <p>Email :  {data.email}</p>
                            <p>Mobile :  {data.mobile}</p>
                            <button className='mt-5 btn btn-primary' data-toggle="modal" data-target="#myModal" onClick={() => editdata(data.id)}>EDIT PROFILE</button>
                        </div>
                    </div>
                    <div className="col-lg-4 col-md-4">
                        <div className="img-box">
                            <img src={data.img} alt />
                        </div>
                    </div>
                </div>

                <div className="modal" id="myModal">
                                    <div className="modal-dialog">
                                        <div className="modal-content">
                                            {/* Modal Header */}
                                            <div className="modal-header">
                                                <h4 className="modal-title">Edit Profile</h4>
                                                <button type="button" className="close" data-dismiss="modal">×</button>
                                            </div>
                                            {/* Modal body */}
                                            <div className="modal-body">
                                                <form action="">
                                                    <div className="mb-3 mt-3">
                                                        <label htmlFor="Name">Name:</label>
                                                        <input type="text" value={formvalue.name} onChange={changehandel} className="form-control" id="Name" placeholder="Enter Name" name="name" />
                                                    </div>
                                                    <div className="mb-3 mt-3">
                                                        <label htmlFor="email">Email:</label>
                                                        <input type="email" value={formvalue.email} onChange={changehandel} className="form-control" id="email" placeholder="Enter email" name="email" />
                                                    </div>
                                                    
                                                    <div className="mb-3">
                                                        <label htmlFor="mobile">Mobile:</label>
                                                        <input type="number" value={formvalue.mobile} onChange={changehandel} className="form-control" id="pwd" placeholder="Enter Mobile" name="mobile" />
                                                    </div>
                                                    <div className="mb-3">
                                                        <label htmlFor="mobile">Upload Img:</label>
                                                        <input type="url" value={formvalue.img} onChange={changehandel} className="form-control" id="pwd" placeholder="Enter Image URL" name="img" />
                                                    </div>
                                                    <button type="submit" onClick={submithandel} data-dismiss="modal"  className="btn btn-primary">Save</button>
                                                   
                                                </form>
                                            </div>
                                            
                                        </div>
                                    </div>
                                </div>  

            </div>
        </section>

    )
}

export default Profile