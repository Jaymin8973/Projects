import React from 'react'

function About() {
  return (
   <div>
  {/* about breadcrumb */}
  <section className="w3l-about-breadcrumb text-center">
    <div className="breadcrumb-bg breadcrumb-bg-about py-sm-5 py-4">
      <div className="container py-2">
        <h2 className="title">About Me</h2>
        <ul className="breadcrumbs-custom-path mt-2">
          <li><a href="#url">Home</a></li>
          <li className="active"><span className="fa fa-arrow-right mx-2" aria-hidden="true" /> About Me </li>
        </ul>
      </div>
    </div>
  </section>
  {/* //about breadcrumb */}
  {/* about page about section */}
  <section className="w3l-aboutblock1" id="about">
    <div className="midd-w3 py-5">
      <div className="container py-lg-5 py-md-3">
        <div className="row">
          <div className="col-lg-4">
            <div className="position-relative">
              <img src="assets/images/myphoto1.jpg" alt className="radius-image img-fluid" />
            </div>
          </div>
          <div className="col-lg-8 mt-lg-0 mt-5">
            <h5 className="title-small mb-2">Hello, I am UI/UX Designer</h5>
            <h3 className="title-big">Having O7 Years of Experience</h3>
            <p className="mt-4">Lorem ipsum viverra feugiat. Pellen tesque libero ut justo,
              ultrices in ligula. Semper at tempufddfel. Lorem ipsum dolor sit amet consectetur adipisicing
              elit. Non quae, fugiat consequatur voluptatem nihil ad. Lorem ipsum dolor sit amet.</p>
            <div className="my-info mt-4">
              <div className="single-info"><span>Name:</span>
                <p>Alexander Smith</p>
              </div>
              <div className="single-info"><span>Age:</span>
                <p>24 Years</p>
              </div>
              <div className="single-info"><span>From:</span>
                <p>London, UK</p>
              </div>
              <div className="single-info"><span>Email:</span>
                <p><a href="mailto:alexander@mail.com">alexander@mail.com</a></p>
              </div>
            </div>
            <div className="my-social mt-lg-5 mt-4">
              <a href="#download" className="btn btn-style btn-primary">Download CV</a>
              <ul className="social m-0 p-0">
                <li><a href="#twitter"><span className="fa fa-twitter" /></a></li>
                <li><a href="#instagram"><span className="fa fa-instagram" /></a></li>
                <li><a href="#facebook"><span className="fa fa-facebook-official" /></a></li>
                <li><a href="#linkedin"><span className="fa fa-linkedin-square" /></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* //about page about section */}
  {/* about page second section */}
  <div className="py-5 w3l-resume">
    <div className="container py-lg-5 py-3">
      <h5 className="title-small mb-2"> Hello</h5>
      <h3 className="title-big mb-4">I Can give your business a new Creative start right away! </h3>
      <p>I am a freelancer based in the United Kingdom and i have been building noteworthy UX/UI designs and websites
        for years, which comply with the latest design trends. I help convert a vision and an idea into meaningful
        and useful products. Having a sharp eye for product evolution helps me prioritize tasks, iterate fast and
        deliver faster</p>
      <div className="row features-w3pvt-main mt-5 pt-md-3" id="features">
        <div className="col-lg-4 col-md-6 feature-gird">
          <div className="row features-hny-inner-gd">
            <div className="col-md-2 col-2 featured_grid_left">
              <div className="icon_left_grid">
                <span className="fa fa-laptop" aria-hidden="true" />
              </div>
            </div>
            <div className="col-md-10 col-10 featured_grid_right_info">
              <h4><a className="link-hny" href="#url">Responsive Design </a></h4>
              <p>Lorem ipsum dolor sit amet elit consec tetur adipisi elit., rem!</p>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-md-6 feature-gird mt-md-0 mt-4">
          <div className="row features-hny-inner-gd">
            <div className="col-md-2 col-2 featured_grid_left">
              <div className="icon_left_grid">
                <span className="fa fa-pencil-square-o" aria-hidden="true" />
              </div>
            </div>
            <div className="col-md-10 col-10 featured_grid_right_info">
              <h4><a className="link-hny" href="#url">Powerful Editor </a></h4>
              <p>Lorem ipsum dolor sit amet elit consec tetur adipisi elit., rem!</p>
            </div>
          </div>
        </div>
        <div className="col-lg-4 col-md-6 feature-gird mt-lg-0 mt-md-5 mt-4">
          <div className="row features-hny-inner-gd">
            <div className="col-md-2 col-2 featured_grid_left">
              <div className="icon_left_grid">
                <span className="fa fa-desktop" aria-hidden="true" />
              </div>
            </div>
            <div className="col-md-10 col-10 featured_grid_right_info">
              <h4><a className="link-hny" href="#url">Creative Design </a></h4>
              <p>Lorem ipsum dolor sit amet elit consec tetur adipisi elit., rem!</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  {/* //about page about section */}
  {/* about page third section */}
  <section className="w3l-content-6 py-5">
    <div className="content-6-mian py-lg-5 py-md-4">
      <div className="container">
        <div className="content-info-in row">
          <div className="content-gd col-lg-5">
            <h3 className="title-big mb-4">Motivated by the Desire to achieve Success</h3>
            <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Dolorem, odit! Perspiciatis et
              consequuntur non, modi quo mollitia labore laborum voluptas quia officiis fugit soluta molestias
              quaerat sapiente sunt.
            </p>
          </div>
          <div className="content-gd col-lg-6 offset-lg-1">
            <div className="progress-info">
              <h6 className="progress-tittle">UI/UX Design</h6>
              <div className="progress">
                <div className="progress-bar progress-bar-striped" role="progressbar" style={{width: '80%'}} aria-valuenow={80} aria-valuemin={0} aria-valuemax={100}>
                </div>
              </div>
            </div>
            <div className="progress-info">
              <h6 className="progress-tittle">Ideas &amp; Technology
              </h6>
              <div className="progress">
                <div className="progress-bar progress-bar-striped" role="progressbar" style={{width: '95%'}} aria-valuenow={95} aria-valuemin={0} aria-valuemax={100}>
                </div>
              </div>
            </div>
            <div className="progress-info">
              <h6 className="progress-tittle">Branding Design</h6>
              <div className="progress">
                <div className="progress-bar progress-bar-striped" role="progressbar" style={{width: '55%'}} aria-valuenow={55} aria-valuemin={0} aria-valuemax={100}>
                </div>
              </div>
            </div>
            <div className="progress-info mb-0">
              <h6 className="progress-tittle">Responsive Web Design</h6>
              <div className="progress">
                <div className="progress-bar progress-bar-striped" role="progressbar" style={{width: '80%'}} aria-valuenow={80} aria-valuemin={0} aria-valuemax={100}>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* about page third section */}
  {/* subscribe block */}
  <div className="abouthy-img-grids">
    <div className="img-one">
      <img src="assets/images/g5.jpg" alt=" " className="img-fluid" />
    </div>
    <div className="img-one content-mid">
      <h3 className="title-big"> Stay up to date, Subscribe to the free Newsletter! </h3>
      <form action="#url" method="GET" className="subscribe-form">
        <input type="email" name="email" placeholder="Enter your email" required />
        <button type="submit" className="btn">Subscribe</button>
      </form>
    </div>
    <div className="img-one">
      <img src="assets/images/g3.jpg" alt=" " className="img-fluid" />
    </div>
  </div>
  {/* //subscribe block */}
  {/* achievements block */}
  <section className="w3l-services">
    <div className="w3l-achievements py-5" id="services">
      <div className="container py-lg-5">
        <h5 className="title-small text-center">My achievements</h5>
        <h3 className="title-big text-center mb-sm-5 mb-4">Personal Awards</h3>
        <div className="row">
          <div className="col-lg-6 item">
            <div className="card">
              <div className="box-wrap">
                <div className="icon">
                  <span className="fa fa-globe" />
                </div>
                <h4><a href="#url">Website of the day</a></h4>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi reiciendis labore quisquam
                  suscipit qui veritatis. voluptas quia officiis fugit soluta sunt</p>
              </div>
            </div>
          </div>
          <div className="col-lg-6 item">
            <div className="card">
              <div className="box-wrap">
                <div className="icon">
                  <span className="fa fa-laptop" />
                </div>
                <h4><a href="#url"> Awards Site Of The Day</a></h4>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi reiciendis labore quisquam
                  suscipit qui veritatis. voluptas quia officiis fugit soluta sunt</p>
              </div>
            </div>
          </div>
          <div className="col-lg-6 item">
            <div className="card">
              <div className="box-wrap mb-lg-0">
                <div className="icon">
                  <span className="fa fa-trophy" />
                </div>
                <h4><a href="#url">Honorable mention award</a></h4>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi reiciendis labore quisquam
                  suscipit qui veritatis. voluptas quia officiis fugit soluta sunt</p>
              </div>
            </div>
          </div>
          <div className="col-lg-6 item">
            <div className="card">
              <div className="box-wrap mb-0">
                <div className="icon">
                  <span className="fa fa-laptop" />
                </div>
                <h4><a href="#url">Designer of the Company</a></h4>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi reiciendis labore quisquam
                  suscipit qui veritatis. voluptas quia officiis fugit soluta sunt</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  {/* //achievements block */}
</div>

  )
}

export default About