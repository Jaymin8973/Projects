import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { BrowserRouter,Routes,Route } from "react-router-dom";
import Header from "./Component/Header";
import Footer from "./Component/Footer";
import Index from "./Pages/Index";
import About from "./Pages/About";
import Contact from "./Pages/Contact";
import Login from "./Pages/Login";
import Signup from "./Pages/Signup";
import Profile from './Pages/Profile';
import Services from './Pages/Service';



function App() {
  return (
    <>
    <ToastContainer></ToastContainer>
    <BrowserRouter>
    <Routes>
    <Route path="/profile" element={<><Header/><Profile/><Footer/></>}></Route>
    <Route path="/service" element={<><Header/><Services/><Footer/></>}></Route>
      <Route path="/" element={<><Header/><Index/><Footer/></>}></Route>
      <Route path="/about" element={<><Header/><About/><Footer/></>}></Route>
      <Route path="/contact" element={<><Header/><Contact/><Footer/></>}></Route>
      <Route path="/login" element={<><Header/><Login/><Footer/></>}></Route>
      <Route path="/signup" element={<><Header/><Signup/><Footer/></>}></Route>
    </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
